Attention! The project uses the temporary output 'QGLViewerWidget.moc.cc' from
the project QtViewer. Therefore one must build first the QtViewer before building
this projects.
